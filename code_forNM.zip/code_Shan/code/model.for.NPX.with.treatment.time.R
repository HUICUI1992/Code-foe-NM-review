library(readxl)
library(lme4)
library(lmerTest)
library(broom.mixed)
library(dplyr)
library(ggplot2)
library(ggrepel)
library(ggprism)
library(ggsci)
NPX=read_excel('../data/Olink.upload.data.xlsx',sheet=1)
NPX=data.frame(NPX)

# Calculate change in FVC (Forced Vital Capacity) between end of treatment and baseline
NPX$dFVC=NPX$Visit.6..EOT.-NPX$Baseline

# Convert visit information to numeric days for temporal analysis
NPX$VISIT1=1
NPX$VISIT1[NPX$VISIT=='V5W8D57']=57      # Week 8
NPX$VISIT1[NPX$VISIT=='V3W2D15']=15      # Week 2
NPX$VISIT1[NPX$VISIT=='V4W4D29']=29      # Week 4
NPX$VISIT1[NPX$VISIT=='V6W12D85/EOT']=85 # Week 12/End of Treatment

# Set treatment groups as factors with specific order
NPX$TREATMENT=factor(NPX$TREATMENT,levels = c('Placebo','INS018_055 30 mg QD','INS018_055 30 mg BID','INS018_055 60 mg QD'))

# Initialize empty dataframe for results
re1=data.frame()

# Analyze treatment effects on protein expression over time
# Loop through each protein measurement
print('Analyzing treatment effects on protein expression over time...')
print('This step takes about 10 minutes...')
for (i in colnames(NPX)[7:(ncol(NPX)-2)]){
  # Prepare data for current protein
  tmp_dt=NPX[,c('PatientID','TREATMENT','VISIT1',i)]
  colnames(tmp_dt)=c('SUBJID','TREATMENT','VISIT1','NPX')
  tmp_dt=unique(tmp_dt)
  
  # Fit linear mixed effects model
  # Model includes: 
  # - Fixed effects for treatment and time
  # - Treatment:time interaction
  # - Random intercept for each subject
  model <- tidy(lmer(NPX ~TREATMENT+VISIT1+ VISIT1:TREATMENT+(1|SUBJID), data = tmp_dt))
  
  # Extract relevant model statistics
  model=model %>% select(term, estimate, std.error, p.value)
  model=model[6:8,]  # Keep only treatment:time interaction terms
  model$Assay=i
  re1=rbind(re1,model)
}

# Categorize results based on statistical significance and effect direction
re1$G1=ifelse(re1$p.value<0.05,ifelse(re1$estimate<0,'Down','Up'),'Not significant')
re1=re1[order(re1$p.value,decreasing = F),]  # Sort by p-value
re1$G1=factor(re1$G1,levels = c('Down','Not significant','Up'))
re1$label=ifelse(re1$G1=='Not significant','',re1$Assay)

# Prepare labels for volcano plot
# Reset all labels first
re1$label=''
re1=re1[order(re1$p.value,decreasing = F),]

# Label top 20 most significant proteins for each treatment group
re1[re1$term=='TREATMENTINS018_055 30 mg BID:VISIT1',][1:20,]$label=re1[re1$term=='TREATMENTINS018_055 30 mg BID:VISIT1',][1:20,]$Assay
re1[re1$term=='TREATMENTINS018_055 60 mg QD:VISIT1',][1:20,]$label=re1[re1$term=='TREATMENTINS018_055 60 mg QD:VISIT1',][1:20,]$Assay

# Create volcano plots
pdf('volcano.plots.pdf',width=16,height = 7)
# Generate volcano plot showing treatment effects on protein expression
# - X-axis: effect size (estimate)
# - Y-axis: statistical significance (-log10(p-value))
# - Colors: direction of change and significance
# - Labels: top 20 most significant proteins
ggplot(re1[re1$term %in% c('TREATMENTINS018_055 30 mg BID:VISIT1',"TREATMENTINS018_055 60 mg QD:VISIT1" ),],
       aes(x=estimate,y=-log10(p.value)))+
  geom_point(aes(color=G1),size=2)+
  theme_prism()+
  scale_color_nejm()+
  ggrepel::geom_label_repel(aes(label=label),max.overlaps = 30)+
  facet_wrap(~term,scales = 'free')
dev.off()