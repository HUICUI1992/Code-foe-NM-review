library(ggplot2)
library(ggsci)
library(ggprism)
library(ggsignif)
library(readxl)

NPX=read_excel('../data/Olink.upload.data.xlsx',sheet=1)
NPX=data.frame(NPX)
NPX$dFVC=NPX$Visit.6..EOT.-NPX$Baseline
gene='CCN2'
tmp_dt=NPX[,c('VISIT',gene,"TREATMENT",'dFVC')]
tmp_dt$VISIT[tmp_dt$VISIT=='V5W8D57']='V6W12D85/EOT'
## Patient sample exclueded for the FVC outliner confirmed by the clincial Team
tmp_dt=tmp_dt[-which(tmp_dt$TREATMENT=='Placebo' & tmp_dt$dFVC>200),]
colnames(tmp_dt)=c(c('VISIT','NPX',"TREATMENT",'dFVC'))
tmp_dt$dNPX=0
tmp_dt$dNPX[tmp_dt$VISIT=='V4W4D29']=tmp_dt$NPX[tmp_dt$VISIT=='V4W4D29']-tmp_dt$NPX[tmp_dt$VISIT=='V2W0D1']
tmp_dt$dNPX[tmp_dt$VISIT=='V6W12D85/EOT']=tmp_dt$NPX[tmp_dt$VISIT=='V6W12D85/EOT']-tmp_dt$NPX[tmp_dt$VISIT=='V2W0D1']
tmp_dt$dNPX[tmp_dt$VISIT=='V3W2D15']=tmp_dt$NPX[tmp_dt$VISIT=='V3W2D15']-tmp_dt$NPX[tmp_dt$VISIT=='V2W0D1']
p2=ggplot(tmp_dt[tmp_dt$VISIT!='V2W0D1',],aes(x=dNPX,y=dFVC))+geom_point(aes(color=TREATMENT))+geom_smooth(method = 'glm',se=F)+
  theme_prism()+xlab(paste(gene,'ΔNPX from Baseline'))+ facet_wrap(~VISIT,nrow=1)+ylab('ΔFVC from baseline')+
  theme(axis.text.x = element_text(angle = 60, hjust = 1,vjust=1))+ scale_color_nejm()+labs(title=gene)
print(p2)
ggsave(paste0(gene,'_p2.pdf'),p2,width=10,height=5)
