library(readxl)
library(lme4)
library(lmerTest)
library(broom.mixed)
library(dplyr)
NPX=read_excel('../data/Olink.upload.data.xlsx',sheet=1)

# Convert to data frame and calculate FVC change (delta FVC)
NPX=data.frame(NPX)
NPX$dFVC=NPX$Visit.6..EOT.-NPX$Baseline  # Calculate change in FVC between end of treatment and baseline

# Convert visit information to numeric days
NPX$VISIT1=1
NPX$VISIT1[NPX$VISIT=='V5W8D57']=57      # Week 8
NPX$VISIT1[NPX$VISIT=='V3W2D15']=15      # Week 2
NPX$VISIT1[NPX$VISIT=='V4W4D29']=29      # Week 4
NPX$VISIT1[NPX$VISIT=='V6W12D85/EOT']=85 # Week 12/End of Treatment

# Set treatment factor levels in specific order
NPX$TREATMENT=factor(NPX$TREATMENT,levels = c('Placebo','INS018_055 30 mg QD','INS018_055 30 mg BID','INS018_055 60 mg QD'))

# Initialize empty dataframe to store protein expression slopes
re.FVC1.slope=data.frame()

# Calculate slopes for each protein and subject
# This loop processes each protein measurement column (from column 7 to the end, excluding last 2 columns)
print('Calculating slopes for each protein and subject...')
print('This step takes about 10 minutes...')
for (i in colnames(NPX)[7:(ncol(NPX)-2)]){
  # Extract data for current protein
  tmp_dt=NPX[,c('VISIT1',i,'PatientID')]
  colnames(tmp_dt)=c('VISIT1','NPX','SUBJID')
  
  # Calculate slope for each subject
  for (j in unique(tmp_dt$SUBJID)){
    tmp_dt1=tmp_dt[tmp_dt$SUBJID==j,]
    tmp_dt1=tmp_dt1[,c('NPX','VISIT1')]
    # Fit linear model to get protein expression change over time
    a=tidy(lm(NPX ~ VISIT1, data = tmp_dt1))
    slope=a[2,2]  # Extract slope coefficient
    # Store results
    re1=data.frame(c(j,i,slope))
    colnames(re1)=c('SUBJID','Assay','Slope')
    re.FVC1.slope=rbind(re.FVC1.slope,re1)
  }}

# Prepare dataset for final analysis
# Extract unique patient IDs and their FVC changes
NPX.need=NPX[,c('PatientID','dFVC')]
NPX.need=unique(NPX.need)
colnames(NPX.need)=c('SUBJID','dFVC')
# Merge with slope data
NPX.need=merge(NPX.need,re.FVC1.slope,by='SUBJID')

# Initialize empty dataframe for final results
re.FVC1=data.frame()

# Analyze relationship between protein slopes and FVC change
for (i in unique(NPX.need$Assay)){
  # For each protein, fit linear model to see if protein change predicts FVC change
  tmp_dt=NPX.need[NPX.need$Assay==i,]
  a=tidy(lm(dFVC ~ Slope, data = tmp_dt))
  a=a[2,]  # Extract slope coefficient
  a$Assay=i
  re.FVC1=rbind(re.FVC1,a)
}
write.csv(re.FVC1,'re.FVC1.csv',row.names = F)


