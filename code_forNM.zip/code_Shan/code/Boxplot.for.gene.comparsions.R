library(ggplot2)
library(ggsci)
library(ggprism)
library(ggsignif)
library(readxl)
NPX=read_excel('../data/Olink.upload.data.xlsx',sheet=1)
NPX=data.frame(NPX)
NPX$VISIT[NPX$VISIT=='V5W8D57']='V6W12D85/EOT'
NPX=NPX[order(NPX$PatientID),]
my_comparsions=list(c('V2W0D1','V3W2D15'),c('V2W0D1','V4W4D29'),c('V2W0D1','V6W12D85/EOT'))
gene='CXCL12'
tmp_dt=NPX[,c('VISIT',gene,'TREATMENT','PatientID')]
colnames(tmp_dt)=c('VISIT','NPX','TREATMENT','SUBJID')
p4=ggplot(tmp_dt,aes(x=VISIT,y=NPX))+geom_boxplot(width=0.3,outlier.shape = NA)+
  geom_point(aes(color=TREATMENT))+geom_line(aes(group=SUBJID))+facet_wrap(~TREATMENT,nrow=1)+
  theme_prism()+xlab('')+theme(legend.position = 'none')+labs(y=paste(gene,'NPX'))+
  theme(axis.text.x = element_text(angle = 60, hjust = 1,vjust=1))+
  scale_color_nejm()+ggsignif::geom_signif(comparisons = my_comparsions,test = 't.test',test.args = list(paired = TRUE),step_increase = 0.1,tip_length = 0)
print(p4)
ggsave(paste0(gene,'_p4.pdf'),p4,width=10,height=5)

p5=ggplot(tmp_dt,aes(x=VISIT,y=NPX,group=TREATMENT))+stat_summary(fun = mean, geom = "line",aes(color=TREATMENT)) +
  stat_summary(fun = mean, geom = "point",aes(color=TREATMENT))+
    stat_summary(fun.data = mean_se, geom = "errorbar", width = 0.1)+
  theme_prism()+xlab('')+labs(y=paste('Osteopontin','NPX'))+
  theme(axis.text.x = element_text(angle = 60, hjust = 1,vjust=1))+scale_x_discrete(label=c('Week 0','Week 2','Week 4','Week 12'))+
  scale_color_nejm()#+stat_compare_means(aes(group = TREATMENT, color=TREATMENT), method = "anova", label = "p.signif")
#+ggsignif::geom_signif(comparisons = my_comparsions,test = 't.test',test.args = list(paired = TRUE),step_increase = 0.1,tip_length = 0)
print(p5)
ggsave(paste0(gene,'_p5.pdf'),p5,width=10,height=5)
